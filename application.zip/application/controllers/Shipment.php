<?php
class Shipment extends CI_Controller {

    public function __construct() {
       parent::__construct();
      
       $this->load->model('user_auth_model');
       $this->load->model('shipment_model');

    }

    public function add(){
      	  
    }

    public function add(){
      	  
    }


}


