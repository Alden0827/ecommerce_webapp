<?php
class Test extends CI_Controller {

    public function test1(){
    	print('<pre>');
    	print_r($_SERVER);
    	print('</pre>');
    }




}

