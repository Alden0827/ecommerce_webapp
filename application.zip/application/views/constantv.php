<?php
	// define("app_name", "Sample Store Name!", true);
	// define("database", "db_ecommerce", true);
	// define("username", "root", true);
	// define("password", "", true);

?>